/* CalorieToken — explicit, Testnet-only onboarding; GPL-2.0-or-later. */
(function () {
  'use strict';
  function safeQueryKey(key){return key==='ui_lang'||/^(?:utm_(?:source|medium|campaign|term|content|id)|gclid|dclid|fbclid|msclkid|ttclid|twclid)$/.test(key);}
  var cfg = window.CalorieTokenDiscovery;
  if (!cfg || !cfg.testCopy || Number(cfg.page) !== 7880 || window.CalorieTokenTestnet) return;
  var faucet = 'https://faucet.altnet.rippletest.net/accounts';
  var ledger = 'wss://s.altnet.rippletest.net:51233/';
  var panel = null, fields = [], ui = {}, locale = 'en', status = 'ready', step = 0;
  var account = null, busy = false, controller = null, cancelLedger = null, generation = 0, departed = false;
  // Courtesy limits for ordinary UI use, not a server-side anti-bot boundary.
  // Only two deadlines survive a tab reload; account data is never stored.
  var delayKey = 'ctstyle-testnet-delays-v1', retryAt = {create:0,check:0}, delayTimer = null;
  // Screens shown in the official Xaman Help Center, checked 2026-09-12.
  // These are explanatory examples, never the visitor's account or recovery code.
  var xamanNetworkHelp = 'https://help.xaman.app/app/learning-more-about-xaman/how-to-access-testnet-on-xrp-ledger';
  var xamanImportHelp = 'https://help.xaman.app/app/getting-started-with-xaman/importing-your-account/...with-a-family-seed';
  var xamanImageBase = 'https://3221812686-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2FMiHAzvIPISVuuzt0AeOR%2Fuploads%2Fgit-blob-';
  var visualSteps = {
    network: [
      ['networkDeveloper','f97686945ca4276bb87e45654d2529c4d44c1326%2Ftestnet1.png'],
      ['networkSwitch','9517def83a3cb4ad4be369efc66f22b265a7dd4e%2Ftestnet2.png'],
      ['networkSelect','add493570aca56ed3d792e003e912baefd522cc9%2Ftestnet3.png']
    ],
    import: [
      ['importExisting','c2507fa8c45680bf67708abef70ddda9a2d50078%2FAdd%20an%20account%20screen.png'],
      ['importAccess','fe6631be444cb4e6f89ec863da04a118bc9125e9%2FAccount%20type.png'],
      ['importFamily','ffdeaf6ae24435ba78bd7e977166ddf217b946ef%2FFamily%20Seed%20-%201.png']
    ]
  };
  function readDelays() {
    try {
      var saved = JSON.parse(window.sessionStorage.getItem(delayKey) || 'null');
      ['create','check'].forEach(function (key) {
        var value = saved && saved[key];
        if (Number.isSafeInteger(value) && value > 0) retryAt[key] = Math.max(retryAt[key],value);
      });
    } catch (_) { /* Storage may be blocked; the current page still keeps its delay. */ }
  }
  function delayRequest(key, milliseconds) {
    retryAt[key] = Math.max(retryAt[key],Date.now()+milliseconds);
    try { window.sessionStorage.setItem(delayKey,JSON.stringify(retryAt)); } catch (_) {}
  }
  function remaining(key) { return Math.max(0,Math.ceil((retryAt[key]-Date.now())/1000)); }
  function providerDelay(value) {
    if (!value) return 60000;
    value = value.trim();
    var delay = /^\d{1,10}$/.test(value) ? Number(value)*1000 : Date.parse(value)-Date.now();
    return Number.isFinite(delay) ? Math.max(60000,delay) : 60000;
  }
  function requestControls() {
    window.clearTimeout(delayTimer); delayTimer = null;
    var createWait = remaining('create'), checkWait = remaining('check'), words = cfg.testCopy[locale];
    ui.create.disabled = busy || !!account || status === 'unsupported' || createWait > 0;
    ui.check.disabled = busy || checkWait > 0;
    var createText = !busy && !account && createWait ? words.waitCreate.replace('{seconds}',new Intl.NumberFormat(locale).format(createWait)) : words.create;
    var checkText = !busy && account && status !== 'funded' && checkWait ? words.waitCheck.replace('{seconds}',new Intl.NumberFormat(locale).format(checkWait)) : words.check;
    if (ui.create.textContent !== createText) ui.create.textContent = createText;
    if (ui.check.textContent !== checkText) ui.check.textContent = checkText;
    if (!departed && !busy && ((!account && createWait) || (account && status !== 'funded' && checkWait))) {
      delayTimer = window.setTimeout(requestControls,1000);
    }
  }
  function allowed() {
    return !departed && document.body.matches('.ctstyle-enabled.page-id-7880') &&
      !document.body.matches('.brz-ed') && !document.querySelector('.brz-ed,#brz-ed-iframe') &&
      ['https://calorietoken.net','https://www.calorietoken.net'].includes(window.location.origin) &&
      ['/index.php/calorieapp/','/calorieapp/'].includes(window.location.pathname) &&
      Array.from(new URL(window.location.href).searchParams.keys()).every(safeQueryKey);
  }
  function el(tag, key, cls) {
    var node = document.createElement(tag); if (cls) node.className = cls;
    if (key) { fields.push({node:node,key:key}); node.textContent = cfg.testCopy[locale][key]; }
    return node;
  }
  function button(key) { var node = el('button',key,'ctstyle-discovery-action'); node.type = 'button'; return node; }
  function pictureGuide(kind) {
    var guide = el('div',null,'ctstyle-xaman-guide'), list = el('ol',null,'ctstyle-xaman-screens');
    visualSteps[kind].forEach(function (row) {
      var item = el('li'), caption = el('p',row[0]), figure = el('figure'), picture = el('img'), zoom = el('a',null,'ctstyle-xaman-enlarge');
      var source = el('a','screenshotSource');
      source.href = kind === 'network' ? xamanNetworkHelp : xamanImportHelp;
      source.target = '_blank'; source.rel = 'noopener noreferrer';
      picture.src = xamanImageBase + row[1] + '?alt=media';
      picture.loading = 'lazy'; picture.decoding = 'async'; picture.referrerPolicy = 'no-referrer';
      picture.alt = cfg.testCopy[locale][row[0]];
      fields.push({node:picture,key:row[0],attribute:'alt'});
      zoom.href = picture.src; zoom.target = '_blank'; zoom.rel = 'noopener noreferrer';
      zoom.setAttribute('aria-label',cfg.testCopy[locale].enlargeScreenshot);
      fields.push({node:zoom,key:'enlargeScreenshot',attribute:'aria-label'});
      zoom.append(picture);
      var credit = el('figcaption'); credit.append(source);
      figure.append(zoom,credit); item.append(caption,figure); list.append(item);
    });
    guide.append(list,el('p','screenshotNote','ctstyle-discovery-small'));
    return guide;
  }
  function render() {
    if (!panel) return;
    fields.forEach(function (entry) {
      if (entry.attribute) entry.node.setAttribute(entry.attribute,cfg.testCopy[locale][entry.key]);
      else entry.node.textContent = cfg.testCopy[locale][entry.key];
    });
    ui.status.textContent = cfg.testCopy[locale][status];
    ui.status.hidden = status === 'ready';
    ui.create.hidden = !!account;
    ui.check.hidden = !account || status === 'funded';
    ui.result.hidden = !account; panel.setAttribute('aria-busy',busy ? 'true' : 'false');
    ui.importAddress.textContent = account ? account.address : '';
    ui.copySeed.disabled = !account; ui.show.disabled = !account;
    ui.progress.textContent = (step + 1) + ' / 4';
    ui.start.hidden = step !== 0;
    ui.create.hidden = !!account || step !== 0;
    ui.created.hidden = !account;
    ui.steps.forEach(function (node,index) { node.hidden = step !== index + 1; });
    ui.tabs.forEach(function (node,index) {
      node.setAttribute('aria-selected',String(step === index));
      node.tabIndex = step === index ? 0 : -1;
      node.disabled = !account && index > 0;
    });
    ui.previous.hidden = false; ui.previous.disabled = step === 0;
    ui.next.hidden = !account || step >= 3;
    requestControls();
  }
  function go(next) {
    if (!allowed() || !account || next < 0 || next > 3) return;
    step = next;
    // Hide recovery data whenever leaving its step; it remains only in memory.
    ui.secret.textContent = ''; ui.secret.hidden = true; ui.show.setAttribute('aria-expanded','false');
    render(); var heading = (step === 0 ? ui.start : ui.steps[step - 1]).querySelector('h3');
    heading.tabIndex = -1; heading.focus({preventScroll:false});
  }
  function verify(address) {
    return new Promise(function (resolve, reject) {
      var socket, done = false, timer;
      function finish(ok) {
        if (done) return; done = true; window.clearTimeout(timer); cancelLedger = null;
        if (socket) { socket.onopen = socket.onmessage = socket.onerror = socket.onclose = null; try { socket.close(); } catch (_) {} }
        if (ok) resolve(); else reject(new Error('verification-unavailable'));
      }
      cancelLedger = function () { finish(false); };
      timer = window.setTimeout(function () { finish(false); },15000);
      try {
        socket = new window.WebSocket(ledger);
        socket.onopen = function () {
          socket.send(JSON.stringify({id:1,command:'account_info',account:address,ledger_index:'validated',strict:true}));
        };
        socket.onmessage = function (event) {
          var data; try { data = JSON.parse(event.data); } catch (_) { finish(false); return; }
          if (data.id !== 1) return;
          if (data.warning === 'load') delayRequest('check',60000);
          var result = data.result, info = result && result.account_data;
          finish(data.status === 'success' && result.validated === true && info && info.Account === address &&
            typeof info.Balance === 'string' && /^[0-9]{1,18}$/.test(info.Balance) && Number(info.Balance) > 0);
        };
        socket.onerror = function () { finish(false); };
        socket.onclose = function (event) {
          if (event && event.code === 1008) delayRequest('check',60000);
          finish(false);
        };
      } catch (_) { finish(false); }
    });
  }
  async function check() {
    if (!allowed() || busy || !account) return;
    readDelays(); if (remaining('check')) { requestControls(); return; }
    var current = generation, address = account.address;
    delayRequest('check',15000);
    busy = true; status = 'checking'; render();
    try { await verify(address); if (current === generation && allowed()) status = 'funded'; }
    catch (_) { if (current === generation && allowed()) status = 'pending'; }
    finally { if (current === generation && allowed()) { busy = false; render(); } }
  }
  async function create() {
    if (!allowed() || busy || account || !panel.isConnected) return;
    readDelays(); if (remaining('create')) { requestControls(); return; }
    if (typeof window.fetch !== 'function' || typeof window.AbortController !== 'function' || typeof window.WebSocket !== 'function') {
      status = 'unsupported'; render(); return;
    }
    var current = generation, timeout, response, timedOut = false, request = new window.AbortController();
    delayRequest('create',60000);
    busy = true; status = 'creating'; render(); controller = request;
    try {
      timeout = window.setTimeout(function () { timedOut = true; request.abort(); },25000);
      // No destination supplied: the official faucet creates a fresh TESTNET wallet.
      // Its secret is returned to this browser, never to WordPress or the CalorieApp.
      // The documented empty POST needs no JSON metadata or additional CORS preflight.
      // The browser still enforces the faucet's cross-origin response permission.
      response = await window.fetch(faucet,{method:'POST',mode:'cors',credentials:'omit',cache:'no-store',
        redirect:'error',referrerPolicy:'no-referrer',signal:request.signal});
      if (current !== generation || !allowed()) return;
      if (timedOut) { status = 'timedOut'; return; }
      if (!response.ok) {
        if (response.status === 429 || response.status === 503) delayRequest('create',providerDelay(response.headers.get('retry-after')));
        status = response.status === 429 ? 'limited' : 'failed'; return;
      }
      if (!(response.headers.get('content-type') || '').toLowerCase().startsWith('application/json')) { status = 'invalidResponse'; return; }
      var data = await response.json(), wallet = data && data.account;
      if (current !== generation || !allowed()) return;
      if (timedOut) { status = 'timedOut'; return; }
      var address = wallet && (wallet.classicAddress || wallet.address);
      // The current faucet returns seed beside account; older replies used account.secret.
      // An explicitly supplied current seed must be valid, never replaced by a legacy value.
      var hasSeed = !!data && Object.prototype.hasOwnProperty.call(data,'seed');
      var secret = hasSeed ? data.seed : wallet && wallet.secret;
      if (hasSeed && wallet && Object.prototype.hasOwnProperty.call(wallet,'secret') && wallet.secret !== secret) {
        status = 'invalidResponse'; return;
      }
      // Schema checks only; the official Testnet ledger independently verifies funding below.
      if (typeof address !== 'string' || !/^r[1-9A-HJ-NP-Za-km-z]{24,34}$/.test(address) ||
          typeof secret !== 'string' || !/^s[1-9A-HJ-NP-Za-km-z]{20,34}$/.test(secret)) { status = 'invalidResponse'; return; }
      if (current !== generation || !allowed()) return;
      account = {address:address,secret:secret};
      step = 1;
      ui.address.textContent = address; status = 'created';
    } catch (error) {
      if (current === generation && allowed()) {
        status = timedOut ? 'timedOut' : error && error.name === 'SyntaxError' ? 'invalidResponse' : 'connectionFailed';
      }
    }
    finally {
      window.clearTimeout(timeout); if (controller === request) controller = null;
      if (current === generation && allowed()) { busy = false; render(); }
    }
    if (current === generation && account && allowed()) await check();
  }
  async function copy(kind) {
    if (!allowed() || !account) return;
    var current = generation, value = kind === 'secret' ? account.secret : account.address;
    try {
      if (!navigator.clipboard || typeof navigator.clipboard.writeText !== 'function') throw new Error('clipboard-unavailable');
      await navigator.clipboard.writeText(value);
      if (current === generation && allowed()) ui.copyStatus.textContent = cfg.testCopy[locale].copied;
    } catch (_) {
      if (current !== generation || !allowed()) return;
      if (kind === 'secret') { ui.secret.textContent = account.secret; ui.secret.hidden = false; ui.show.setAttribute('aria-expanded','true'); }
      ui.copyStatus.textContent = cfg.testCopy[locale].manualCopy;
    }
  }
  function mount() {
    if (!allowed() || panel) return;
    var roots = document.querySelectorAll('#ctstyle-testnet[data-ctstyle-testnet="1"]');
    if (roots.length !== 1 || roots[0].closest('form,[data-calorieapp-embed],[contenteditable],[hidden],[inert]')) return;
    var root = roots[0], help = root.querySelector('.ctstyle-test-steps'); if (!help) return;
    panel = el('div',null,'ctstyle-testnet-create'); panel.id = 'ctstyle-testnet-create';
    var tabs = el('div',null,'ctstyle-testnet-tabs'); tabs.setAttribute('role','tablist');
    tabs.setAttribute('aria-label',cfg.testCopy[locale].stepCreate);
    fields.push({node:tabs,key:'stepCreate',attribute:'aria-label'});
    ui.tabs = ['stepCreate','stepNetwork','stepImport','stepReturn'].map(function(key,index){
      var tab = button(key); tab.id = 'ctstyle-testnet-tab-' + (index + 1);
      tab.setAttribute('role','tab'); tab.setAttribute('aria-controls','ctstyle-testnet-step-' + (index + 1));
      tab.addEventListener('click',function(){go(index);});
      tab.addEventListener('keydown',function(event){
        var rtl = locale === 'ar' || locale === 'ur', next = index;
        if(event.key === (rtl ? 'ArrowLeft' : 'ArrowRight') || event.key === 'ArrowDown') next = (index + 1) % 4;
        else if(event.key === (rtl ? 'ArrowRight' : 'ArrowLeft') || event.key === 'ArrowUp') next = (index + 3) % 4;
        else if(event.key === 'Home') next = 0;
        else if(event.key === 'End') next = 3;
        else return;
        event.preventDefault(); if(!ui.tabs[next].disabled){go(next);ui.tabs[next].focus();}
      });
      tabs.append(tab); return tab;
    });
    ui.progress = el('p',null,'ctstyle-testnet-progress'); ui.progress.setAttribute('aria-live','polite');
    ui.start = el('div',null,'ctstyle-testnet-welcome'); ui.start.append(el('h3','stepCreate'),el('p','ready'));
    ui.start.id = 'ctstyle-testnet-step-1'; ui.start.setAttribute('role','tabpanel');ui.start.setAttribute('aria-labelledby','ctstyle-testnet-tab-1');
    ui.created = el('p','created','ctstyle-discovery-status');ui.start.append(ui.created);
    ui.start.append(el('p','keepPageOpen','ctstyle-discovery-small'));
    var preview = el('details',null,'ctstyle-testnet-help ctstyle-testnet-picture-preview');
    preview.append(el('summary','previewPictures'),el('h3','stepNetwork'),pictureGuide('network'),el('h3','stepImport'),pictureGuide('import'));
    ui.start.append(preview);
    ui.create = button('create'); ui.create.id = 'ctstyle-testnet-create-button'; ui.create.addEventListener('click',create);
    ui.status = el('p',null,'ctstyle-discovery-status'); ui.status.setAttribute('role','status'); ui.status.setAttribute('aria-live','polite');
    ui.result = el('div',null,'ctstyle-testnet-result'); ui.result.hidden = true;
    ui.address = el('code'); ui.address.dir = 'ltr'; ui.address.id = 'ctstyle-testnet-address';
    ui.importAddress = el('code'); ui.importAddress.dir = 'ltr';
    ui.secret = el('code'); ui.secret.dir = 'ltr'; ui.secret.hidden = true; ui.secret.id = 'ctstyle-testnet-secret';
    // No user secret input, hidden input, automatic storage, logging, or account data in links/messages.
    ui.show = button('show'); ui.show.setAttribute('aria-controls',ui.secret.id); ui.show.setAttribute('aria-expanded','false');
    ui.show.addEventListener('click',function () {
      if (!allowed() || !account) return;
      ui.secret.hidden = !ui.secret.hidden; ui.secret.textContent = ui.secret.hidden ? '' : account.secret;
      ui.show.setAttribute('aria-expanded',ui.secret.hidden ? 'false' : 'true');
    });
    ui.copySeed = button('copySeed'); ui.copySeed.addEventListener('click',function () { copy('secret'); });
    var copyAddress = button('copyAddress'); copyAddress.addEventListener('click',function () { copy('address'); });
    ui.copyStatus = el('p'); ui.copyStatus.setAttribute('role','status');
    ui.check = button('check'); ui.check.addEventListener('click',check);
    ui.steps = ['stepNetwork','stepImport','stepReturn'].map(function (key,index) {
      var part = el('div',null,'ctstyle-testnet-step'); part.id = 'ctstyle-testnet-step-' + (index + 2);
      part.setAttribute('role','tabpanel');part.setAttribute('aria-labelledby','ctstyle-testnet-tab-' + (index + 2));
      var heading = el('h3',key); heading.tabIndex = -1; part.append(heading); return part;
    });
    var networkHelp = el('a','networkHelp','ctstyle-discovery-action');
    networkHelp.href = xamanNetworkHelp;
    networkHelp.target = '_blank'; networkHelp.rel = 'noopener noreferrer';
    var networkPictures = el('details',null,'ctstyle-testnet-help');networkPictures.append(el('summary','previewPictures'),pictureGuide('network'));
    ui.steps[0].append(el('p','import1'),networkPictures,networkHelp);
    var importHelp = el('a','importHelp','ctstyle-discovery-action');
    importHelp.href = xamanImportHelp;
    importHelp.target = '_blank'; importHelp.rel = 'noopener noreferrer';
    var back = button('back'); back.addEventListener('click',function () {
      var app = document.querySelector('[data-calorieapp-embed]');
      if (app && typeof app.scrollIntoView === 'function') app.scrollIntoView({block:'start',behavior:'auto'});
      else window.scrollTo({top:0,behavior:'auto'});
    });
    var importPictures = el('details',null,'ctstyle-testnet-help');importPictures.append(el('summary','previewPictures'),pictureGuide('import'));
    ui.steps[1].append(el('p','import2'),ui.copySeed,ui.show,ui.secret,ui.copyStatus,el('p','testOnly','ctstyle-discovery-small'),importPictures,el('p','account'),ui.importAddress,el('p','finishImport'),importHelp);
    ui.steps[2].append(el('p','import3'),el('p','account'),ui.address,copyAddress,back,el('p','pilotScope','ctstyle-discovery-small'));
    ui.previous = button('previous'); ui.previous.addEventListener('click',function () { go(step-1); });
    ui.next = button('next'); ui.next.addEventListener('click',function () { go(step+1); });
    var navigation = el('div',null,'ctstyle-testnet-navigation'); navigation.append(ui.previous,ui.next);
    ui.result.append(ui.check); ui.steps.forEach(function (part) { ui.result.append(part); });
    var privacy = el('details',null,'ctstyle-testnet-help'); privacy.append(el('summary','aboutAccount'),el('p','privacy'));
    panel.append(tabs,ui.progress,ui.start,ui.create,ui.status,ui.result,navigation,privacy);
    var official = el('a','official','ctstyle-discovery-action'); official.href = 'https://xrpl.org/resources/dev-tools/xrp-faucets';
    official.target = '_blank'; official.rel = 'noopener noreferrer'; panel.append(official);
    help.before(panel); render();
  }
  function refresh(tag) {
    if (!allowed()) return;
    readDelays();
    if (cfg.testCopy[tag]) locale = tag;
    else if (!panel) {
      var root = document.getElementById('ctstyle-testnet'), initial = (root && root.lang) || document.documentElement.lang;
      if (cfg.testCopy[initial]) locale = initial;
    }
    mount(); render();
  }
  function clear() {
    departed = true; generation += 1;
    if (controller) controller.abort(); if (cancelLedger) cancelLedger();
    account = null; busy = false; status = 'ready'; step = 0;
    if (panel) { ui.address.textContent = ''; ui.secret.textContent = ''; ui.secret.hidden = true; ui.show.setAttribute('aria-expanded','false'); ui.copyStatus.textContent = ''; render(); }
  }
  window.CalorieTokenTestnet = {refresh:refresh,conceal:function(){if(ui.secret){ui.secret.textContent='';ui.secret.hidden=true;ui.show.setAttribute('aria-expanded','false');}}};
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded',function () { refresh(); },{once:true}); else refresh();
  window.addEventListener('load',function () { refresh(); },{once:true});
  window.addEventListener('pagehide',clear);
  window.addEventListener('pageshow',function () { departed = false; refresh(); });
})();
